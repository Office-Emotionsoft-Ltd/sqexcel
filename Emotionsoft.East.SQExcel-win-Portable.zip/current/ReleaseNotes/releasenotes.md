<div class="nutral">

  # What's New in This Version (v0.1.0 Preview)

  This is the first Preview release of SQExcel.

  It is an early-access release, published so that you can try it in a wider range of environments and ways of working, and so that we can improve it based on your feedback.

  When a new version is published, SQExcel will let you know on this "Check for Updates" screen.

  Before working with important data, we recommend making a backup.

  # About SQExcel

  SQExcel (SQL2Excel) is a Windows application that exchanges data between databases and Excel.

  From loading test data during development to maintaining data in production, you can work with your data in the familiar environment of Excel.

  ## Who It's For

  - Developers who want to load and edit test data or initial data quickly during system development
  - Operations and maintenance staff who check and correct data after go-live
  - Teams who want to keep using the same input sheets from development through operation for a smooth handover

  ## What You Can Do with SQExcel

  - Quick Mode: Connect to a database quickly and start working with input sheets right away.
  - Automatic input sheet creation: Reads table definitions (column names, data types, primary keys, and so on) and creates an Excel input sheet for you automatically.
  - Data import: Runs INSERT, UPDATE, UPSERT, and DELETE from an input sheet. The executed statements can also be saved as an SQL script.
  - Data export: Specify search conditions on an input sheet and run it, and the matching data is output to the input sheet. You can then edit the exported data and apply the changes with UPDATE.
  - Flexible data creation: Create the data on an input sheet however you like, using Excel functions, macros, Microsoft 365 Copilot, and more.
  - Project management: Create a "Project" for each target system and register the databases it uses (multiple databases are supported), their connection settings, and sets of tables that are convenient to handle together during maintenance. You can also switch between connections for each environment, such as development, integration testing, and production.

  ## Supported Databases

  SQExcel supports six databases: SQL Server, Oracle, PostgreSQL, MySQL, MariaDB, and SQLite. For the verified versions and other details, see "System Requirements" in the online help.

  ## Online Help and Feedback

  Online help (Japanese only for now): https://sqexcel.net/ja/docs/

  Bug reports: https://github.com/Office-Emotionsoft-Ltd/sqexcel/issues

  Feedback and questions: https://github.com/Office-Emotionsoft-Ltd/sqexcel/discussions

</div>

<div class="ja">

# 今回の更新内容（v0.1.0 Preview版）

SQExcelの最初のPreview版です。

より多くの環境・使い方でお試しいただき、皆さまのご意見をもとに改良を進めるための先行公開版です。

新しいバージョンが公開されると、この「更新プログラムの確認」画面でお知らせします。

重要なデータを操作する前には、バックアップを取っておくことをおすすめします。

# SQExcelについて

SQExcel（SQL2Excel）は、データベースとExcelの間でデータをやり取りするWindowsアプリケーションです。
開発時のテストデータ投入から、運用中のデータメンテナンスまで、使い慣れたExcelでデータを扱えます。

## こんな方のためのツールです

- システム開発中に、テストデータや初期データを手早く投入・修正したい開発者
- 運用・保守フェーズで、データの確認や修正を行う担当者
- 開発から運用まで、同じ入力シートを使い続けてスムーズに引き継ぎたい方

## SQExcelでできること

- クイックモード：データベースへ素早く接続して、すぐに入力シートの操作を始められます。
- 入力シートの自動作成：テーブル定義（項目名・データ型・主キーなど）を読み取り、Excelの入力シートを自動で作成します。
- データ取り込み：入力シートから、INSERT・UPDATE・UPSERT・DELETEを実行します。実行内容はSQLスクリプトとして保存することもできます。
- データ出力：入力シートに検索条件を指定して実行すると、該当するデータが入力シートに出力されます。出力したデータを書き換えて、そのままUPDATEで反映することもできます。
- 自由なデータ作成：入力シートのデータは、Excelの関数やマクロ、Microsoft 365 Copilotなど、お好みの方法で作成できます。
- プロジェクト管理：対象のシステムごとに「プロジェクト」を作成し、そのシステムで使用するデータベース（複数のデータベースにも対応）と接続情報、さらにメンテナンス時にまとめて扱うと便利なテーブルの組み合わせを登録して管理できます。開発・結合テスト・本番など、環境ごとの接続も使い分けられます。

## 対応データベース

SQL Server、Oracle、PostgreSQL、MySQL、MariaDB、SQLiteの6種類に対応しています。動作確認済みのバージョンなどは、オンラインヘルプの「動作環境」をご覧ください。

## オンラインヘルプ・ご意見

オンラインヘルプ：https://sqexcel.net/ja/docs/

不具合のご報告：https://github.com/Office-Emotionsoft-Ltd/sqexcel/issues

ご意見・ご質問：https://github.com/Office-Emotionsoft-Ltd/sqexcel/discussions

</div>
